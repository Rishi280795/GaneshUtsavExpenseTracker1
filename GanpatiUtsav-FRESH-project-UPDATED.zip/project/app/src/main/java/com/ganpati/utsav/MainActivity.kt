package com.ganpati.utsav

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Vargani(
    val id: Long,
    val name: String,
    val mobile: String,
    val expected: Double,
    val paid: Double,
    val mode: String,
    val date: String
) {
    val unpaid: Double get() = (expected - paid).coerceAtLeast(0.0)
}

data class Expense(
    val id: Long,
    val title: String,
    val category: String,
    val amount: Double,
    val date: String,
    val note: String
)

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("ganpati_data", MODE_PRIVATE) }
    private val vargani = mutableListOf<Vargani>()
    private val expenses = mutableListOf<Expense>()
    private val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        buildUi()
        showDashboard()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
        }

        val title = TextView(this).apply {
            text = "🕉️ गणपती उत्सव 2026"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 20)
        }
        root.addView(title)

        summary = TextView(this).apply {
            textSize = 18f
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFFFFF3E0.toInt())
        }
        root.addView(summary)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 15, 0, 15)
        }
        nav.addView(button("Dashboard") { showDashboard() })
        nav.addView(button("वर्गणी") { showVargani() })
        nav.addView(button("खर्च") { showExpenses() })
        nav.addView(button("Reports") { showReports() })
        root.addView(nav)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 13f
            minHeight = 54
            minimumHeight = 54
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, 58.dp(), 1f).apply {
                setMargins(4.dp(), 0, 4.dp(), 8.dp())
            }
        }

    private fun actionButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 17f
            minHeight = 60
            minimumHeight = 60
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, 60.dp()).apply {
                setMargins(0, 8.dp(), 0, 8.dp())
            }
        }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun totalExpected() = vargani.sumOf { it.expected }
    private fun totalPaid() = vargani.sumOf { it.paid }
    private fun totalUnpaid() = vargani.sumOf { it.unpaid }
    private fun totalSpent() = expenses.sumOf { it.amount }

    private fun refreshSummary() {
        summary.text = "वर्गणी अपेक्षित: ₹%.2f\nवर्गणी जमा: ₹%.2f\n🔴 वर्गणी बाकी: ₹%.2f\nएकूण खर्च: ₹%.2f\nशिल्लक: ₹%.2f\nवर्गणीदार: %d"
            .format(totalExpected(), totalPaid(), totalUnpaid(), totalSpent(), totalPaid() - totalSpent(), vargani.size)
    }

    private fun clearContent() = content.removeAllViews()

    private fun showDashboard() {
        refreshSummary()
        clearContent()
        addHeader("Dashboard")
        addInfo("या अॅपमधून गणपती उत्सवाची वर्गणी, बाकी रक्कम आणि सर्व खर्चाची नोंद ठेवा.")
        addInfo("वर्गणी अपेक्षित: ₹%.2f".format(totalExpected()))
        addInfo("वर्गणी जमा: ₹%.2f".format(totalPaid()))
        addInfo("🔴 वर्गणी बाकी: ₹%.2f".format(totalUnpaid()))
        addInfo("एकूण खर्च: ₹%.2f".format(totalSpent()))
        addInfo("उपलब्ध शिल्लक: ₹%.2f".format(totalPaid() - totalSpent()))
        content.addView(actionButton("➕ वर्गणी नोंदवा") { showVarganiDialog() })
        content.addView(actionButton("➕ खर्च नोंदवा") { showExpenseDialog() })
    }

    private fun showVargani() {
        refreshSummary()
        clearContent()
        addHeader("वर्गणी / Contribution")
        content.addView(actionButton("➕ नवीन वर्गणी नोंदवा") { showVarganiDialog() })
        addInfo("अपेक्षित: ₹%.2f   |   जमा: ₹%.2f   |   बाकी: ₹%.2f".format(totalExpected(), totalPaid(), totalUnpaid()))

        val search = EditText(this).apply {
            hint = "🔎 नाव किंवा मोबाईल नंबर शोधा"
            textSize = 16f
            singleLine = true
            setPadding(20, 15, 20, 15)
        }
        content.addView(search, LinearLayout.LayoutParams(-1, 58.dp()).apply { setMargins(0, 8.dp(), 0, 8.dp()) })

        val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listContainer)

        fun renderList(query: String) {
            listContainer.removeAllViews()
            val q = query.trim().lowercase(Locale.getDefault())
            val filtered = if (q.isBlank()) vargani else vargani.filter {
                it.name.lowercase(Locale.getDefault()).contains(q) || it.mobile.contains(q)
            }
            if (filtered.isEmpty()) {
                listContainer.addView(card(if (q.isBlank()) "अजून कोणतीही वर्गणी नोंदवलेली नाही." else "🔎 नोंद सापडली नाही."))
                return
            }
            filtered.forEach { item ->
                val status = when {
                    item.unpaid <= 0.009 -> "✅ पूर्ण"
                    item.paid <= 0.009 -> "🔴 पूर्ण बाकी"
                    else -> "🟠 अंशतः जमा"
                }
                val row = card(
                    "👤 ${item.name}\n" +
                    "मोबाईल: ${item.mobile.ifBlank { "-" }}\n" +
                    "अपेक्षित: ₹%.2f | जमा: ₹%.2f\n🔴 बाकी: ₹%.2f | $status\nपद्धत: ${item.mode} | दिनांक: ${item.date}"
                        .format(item.expected, item.paid, item.unpaid)
                )
                row.setOnClickListener { showEditVarganiDialog(item) }
                row.setOnLongClickListener {
                    confirmDelete("ही वर्गणी नोंद हटवायची आहे?") {
                        vargani.remove(item); saveData(); showVargani()
                    }
                    true
                }
                listContainer.addView(row)
            }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderList(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        renderList("")
        addInfo("टीप: नोंद संपादित करण्यासाठी त्यावर टॅप करा. हटवण्यासाठी दीर्घ दाब (Long Press) करा.")
    }

    private fun showExpenses() {
        refreshSummary()
        clearContent()
        addHeader("खर्च / Expenses")
        content.addView(actionButton("➕ नवीन खर्च नोंदवा") { showExpenseDialog() })
        if (expenses.isEmpty()) addInfo("अजून कोणताही खर्च नोंदवलेला नाही.")
        expenses.forEach { item ->
            val row = card(
                "🧾 ${item.title}\n" +
                "वर्ग: ${item.category}\n" +
                "रक्कम: ₹%.2f | ${item.date}\n${item.note}".format(item.amount)
            )
            row.setOnLongClickListener {
                confirmDelete("हा खर्च हटवायचा आहे?") {
                    expenses.remove(item); saveData(); showExpenses()
                }
                true
            }
            content.addView(row)
        }
        addInfo("टीप: नोंद हटवण्यासाठी त्या नोंदीवर दीर्घ दाब (Long Press) करा.")
    }

    private fun showReports() {
        refreshSummary()
        clearContent()
        addHeader("Reports / अहवाल")
        addInfo("💰 वर्गणी अपेक्षित: ₹%.2f".format(totalExpected()))
        addInfo("💵 वर्गणी जमा: ₹%.2f".format(totalPaid()))
        addInfo("💸 एकूण खर्च: ₹%.2f".format(totalSpent()))

        addHeader("खर्चाचा अहवाल / Expense Report")
        if (expenses.isEmpty()) {
            addInfo("खर्च उपलब्ध नाही.")
        } else {
            expenses.forEach { item ->
                addInfo("🧾 ${item.title} | ${item.category} | ₹%.2f | ${item.date}".format(item.amount))
            }
            addHeader("खर्चाचे वर्गीकरण")
            expenses.groupBy { it.category }.forEach { (category, list) ->
                addInfo("$category: ₹%.2f".format(list.sumOf { it.amount }))
            }
        }

        content.addView(actionButton("⬇️ Expenses Report डाउनलोड करा (CSV)") { exportFullReport() })
    }

    private fun exportFullReport() {
        val sb = StringBuilder()
        sb.append("GANPATI UTSAV EXPENSE REPORT\n")
        sb.append("Generated,${dateFormat.format(Date())}\n\n")
        sb.append("VARGANI TOTALS\n")
        sb.append("Total Expected,%.2f\n".format(Locale.US, totalExpected()))
        sb.append("Total Collected,%.2f\n\n".format(Locale.US, totalPaid()))

        sb.append("EXPENSES\n")
        sb.append("Title,Category,Amount,Date,Note\n")
        expenses.forEach {
            sb.append(csv(it.title)).append(",")
                .append(csv(it.category)).append(",")
                .append("%.2f".format(Locale.US, it.amount)).append(",")
                .append(csv(it.date)).append(",")
                .append(csv(it.note)).append("\n")
        }
        sb.append("\nEXPENSE TOTAL,%.2f\n".format(Locale.US, totalSpent()))

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "Ganpati_Utsav_Expense_Report_${dateFormat.format(Date())}.csv")
        }
        pendingReportText = sb.toString()
        startActivityForResult(intent, REQUEST_CREATE_REPORT)
    }

    private fun csv(value: String): String =
        "\"" + value.replace("\"", "\"\"") + "\""

    private var pendingReportText: String? = null

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CREATE_REPORT && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use {
                        it.write((pendingReportText ?: "").toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(this, "Report डाउनलोड झाला.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Report save करता आला नाही.", Toast.LENGTH_LONG).show()
                }
            }
            pendingReportText = null
        }
    }

    private fun addHeader(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 22f
            setPadding(0, 15, 0, 15)
        })
    }

    private fun addInfo(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(15, 15, 15, 15)
        })
    }

    private fun card(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(20, 20, 20, 20)
        setBackgroundColor(0xFFF5F5F5.toInt())
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) }
    }

    private fun showVarganiDialog() {
        val layout = formLayout()
        val name = input("नाव")
        val mobile = input("मोबाईल नंबर")
        val expected = input("ठरलेली / अपेक्षित वर्गणी रक्कम", "numberDecimal")
        val paid = input("जमा झालेली रक्कम", "numberDecimal")
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Cash", "UPI", "Other", "Not Paid"))
        }
        layout.addView(name); layout.addView(mobile); layout.addView(expected); layout.addView(paid); layout.addView(mode)
        AlertDialog.Builder(this)
            .setTitle("वर्गणी नोंदवा")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val expectedValue = expected.text.toString().toDoubleOrNull() ?: 0.0
                val paidValue = paid.text.toString().toDoubleOrNull() ?: 0.0
                if (name.text.toString().trim().isNotEmpty() && expectedValue > 0 && paidValue >= 0) {
                    val safePaid = paidValue.coerceAtMost(expectedValue)
                    vargani.add(Vargani(
                        System.currentTimeMillis(),
                        name.text.toString().trim(),
                        mobile.text.toString().trim(),
                        expectedValue,
                        safePaid,
                        mode.selectedItem.toString(),
                        dateFormat.format(Date())
                    ))
                    saveData(); showVargani()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showEditVarganiDialog(item: Vargani) {
        val layout = formLayout()
        val name = input("नाव").apply { setText(item.name) }
        val mobile = input("मोबाईल नंबर").apply { setText(item.mobile) }
        val expected = input("ठरलेली / अपेक्षित वर्गणी रक्कम", "numberDecimal").apply { setText("%.2f".format(item.expected)) }
        val paid = input("जमा झालेली रक्कम", "numberDecimal").apply { setText("%.2f".format(item.paid)) }
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Cash", "UPI", "Other", "Not Paid"))
            setSelection(maxOf(0, arrayOf("Cash", "UPI", "Other", "Not Paid").indexOf(item.mode)))
        }
        layout.addView(name); layout.addView(mobile); layout.addView(expected); layout.addView(paid); layout.addView(mode)
        AlertDialog.Builder(this)
            .setTitle("वर्गणी नोंद संपादित करा")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Update") { _, _ ->
                val expectedValue = expected.text.toString().toDoubleOrNull() ?: 0.0
                val paidValue = paid.text.toString().toDoubleOrNull() ?: 0.0
                if (name.text.toString().trim().isNotEmpty() && expectedValue > 0 && paidValue >= 0) {
                    val safePaid = paidValue.coerceAtMost(expectedValue)
                    val index = vargani.indexOfFirst { it.id == item.id }
                    if (index >= 0) {
                        vargani[index] = item.copy(
                            name = name.text.toString().trim(),
                            mobile = mobile.text.toString().trim(),
                            expected = expectedValue,
                            paid = safePaid,
                            mode = mode.selectedItem.toString()
                        )
                        saveData(); showVargani()
                    }
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showExpenseDialog() {
        val layout = formLayout()
        val title = input("खर्चाचे नाव")
        val category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Decoration", "Prasad", "Sound", "Lighting", "Pooja Material", "Food", "Mandap", "Other"))
        }
        val amount = input("रक्कम", "numberDecimal")
        val note = input("नोंद / Note")
        layout.addView(title); layout.addView(category); layout.addView(amount); layout.addView(note)
        AlertDialog.Builder(this)
            .setTitle("खर्च नोंदवा")
            .setView(ScrollView(this).apply { addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull() ?: 0.0
                if (title.text.toString().trim().isNotEmpty() && value > 0) {
                    expenses.add(Expense(System.currentTimeMillis(), title.text.toString().trim(),
                        category.selectedItem.toString(), value, dateFormat.format(Date()), note.text.toString().trim()))
                    saveData(); showExpenses()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun formLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(30, 10, 30, 10)
    }

    private fun input(hint: String, type: String = "text") = EditText(this).apply {
        this.hint = hint
        if (type == "numberDecimal") inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        else inputType = android.text.InputType.TYPE_CLASS_TEXT
        setPadding(10, 15, 10, 15)
    }

    private fun confirmDelete(message: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(message)
            .setPositiveButton("Delete") { _, _ -> yes() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun saveData() {
        val v = JSONArray()
        vargani.forEach {
            v.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("mobile", it.mobile)
                put("expected", it.expected); put("paid", it.paid); put("mode", it.mode); put("date", it.date)
            })
        }
        val e = JSONArray()
        expenses.forEach {
            e.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("category", it.category)
                put("amount", it.amount); put("date", it.date); put("note", it.note)
            })
        }
        prefs.edit().putString("vargani", v.toString()).putString("expenses", e.toString()).apply()
    }

    private fun loadData() {
        try {
            val v = JSONArray(prefs.getString("vargani", "[]"))
            for (i in 0 until v.length()) {
                val o = v.getJSONObject(i)
                // Backward compatible with the previous version where "amount" meant paid amount.
                val oldAmount = o.optDouble("amount", 0.0)
                val expected = if (o.has("expected")) o.optDouble("expected", oldAmount) else oldAmount
                val paid = if (o.has("paid")) o.optDouble("paid", oldAmount) else oldAmount
                vargani.add(Vargani(
                    o.getLong("id"),
                    o.optString("name"),
                    o.optString("mobile"),
                    expected,
                    paid,
                    o.optString("mode"),
                    o.optString("date")
                ))
            }
            val e = JSONArray(prefs.getString("expenses", "[]"))
            for (i in 0 until e.length()) {
                val o = e.getJSONObject(i)
                expenses.add(Expense(
                    o.getLong("id"),
                    o.optString("title"),
                    o.optString("category"),
                    o.optDouble("amount", 0.0),
                    o.optString("date"),
                    o.optString("note")
                ))
            }
        } catch (_: Exception) { }
    }

    companion object {
        private const val REQUEST_CREATE_REPORT = 1001
    }
}
