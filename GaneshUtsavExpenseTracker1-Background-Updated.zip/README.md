# Ganpati Utsav Accounts

Android app for Ganpati Utsav contribution (vargani), unpaid amounts, expenses and CSV report export.

## Latest changes
- Search by contributor name or mobile number in the Vargani tab.
- Tap a contributor entry to edit it, including the paid amount when a remaining payment is received.
- Long-press a contributor entry to delete it.
- Reports show only total expected Vargani, total collected Vargani, and the expense report.
- The Reports CSV contains Vargani totals and expense details, but does not list unpaid contributor names.

## GitHub Actions build
1. Upload the **contents of this project** to the repository root (not the ZIP file inside another folder).
2. Make sure these are at the repository root: `app/`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, and `.github/workflows/build-apk.yml`.
3. Open **Actions** -> **Build Ganpati Utsav APK**.
4. Click **Run workflow** (or push to `main` to start it automatically).
5. Open the successful run.
6. Under **Artifacts**, download `GanpatiUtsavAccounts-debug`.
7. Extract it and install `app-debug.apk` on the Android phone.
